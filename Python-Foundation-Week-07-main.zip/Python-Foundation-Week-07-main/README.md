# 📊 Machine Learning Fundamentals – 6 Day Hands-On Roadmap

## 🚀 Overview
This repository documents a structured 6-day hands-on journey through core Machine Learning concepts using Python and scikit-learn. The focus is on building practical understanding through implementation, evaluation, and comparison of models.

---

## 🎯 Objectives
- Understand key Machine Learning paradigms
- Build and evaluate basic models
- Learn proper data splitting techniques
- Apply evaluation metrics effectively
- Develop an end-to-end ML workflow

---

## 📅 Day 1: Supervised vs Unsupervised Learning

### 🔹 Concepts
- Supervised Learning (labeled data)
  - Classification
  - Regression
- Unsupervised Learning (unlabeled data)
  - Clustering
  - Dimensionality Reduction
- Key difference:
  - Supervised → Prediction
  - Unsupervised → Pattern discovery

### 🔹 Tasks
- Classify real-world problems into supervised/unsupervised
- Perform classification (pass/fail prediction)
- Apply clustering techniques
- Visual comparison of results

### 🔹 Examples
- Predict exam scores (Supervised)
- Cluster students based on study habits (Unsupervised)

---

## 📅 Day 2: Scikit-learn Basics

### 🔹 Concepts
- Introduction to `scikit-learn`
- Dataset loading and preprocessing
- Core methods:
  - `.fit()`
  - `.predict()`
  - `.score()`

### 🔹 Tasks
- Load Iris dataset
- Train Decision Tree classifier
- Predict outcomes and evaluate accuracy
- Explore dataset attributes (`.data`, `.target`)

### 🔹 Examples
- Iris classification
- Digit recognition dataset

---

## 📅 Day 3: Train/Test Split

### 🔹 Concepts
- Importance of data splitting:
  - Prevent overfitting
  - Evaluate generalization
- Common ratios: 70/30, 80/20
- Role of `random_state`

### 🔹 Tasks
- Apply `train_test_split`
- Train regression model
- Evaluate on test data
- Compare performance across different splits

### 🔹 Examples
- Student score prediction
- Train vs test performance comparison

---

## 📅 Day 4: Evaluation Metrics

### 🔹 Concepts
- Accuracy (Classification)
- RMSE (Regression)
- Importance of evaluation metrics

### 🔹 Tasks
- Calculate accuracy
- Compute RMSE
- Compare models using metrics
- Interpret results

### 🔹 Examples
- Accuracy on Iris dataset
- RMSE for exam score prediction

---

## 📅 Day 5: Linear Regression

### 🔹 Concepts
- Relationship between independent and dependent variables
- Coefficient (slope) and intercept interpretation
- Regression line visualization

### 🔹 Tasks
- Train linear regression model
- Plot regression line using matplotlib
- Interpret coefficients
- Make predictions

### 🔹 Examples
- Study hours vs scores
- House price prediction

---

## 📅 Day 6: End-to-End Machine Learning Workflow

### 🔹 Concepts
- Complete ML pipeline:
  - Data preprocessing
  - Train/test split
  - Model training
  - Evaluation

### 🔹 Tasks
- Load dataset
- Train regression model
- Evaluate using RMSE
- Compare predicted vs actual values
- Document workflow clearly

### 🔹 Examples
- Student score prediction
- Error analysis

---


